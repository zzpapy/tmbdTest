<!--
为了尽快定位问题，请尽可能填写下面的信息
-->

#### 环境信息

- 系统:
- 浏览器及其版本:

#### 代码片段:

<!--
最好使用 https://jsbin.com https://jsfiddle.net/ https://codepen.io/ 等写个简单的 Demo，方便问题的解决（或者你会直接发现，问题不在 jqPaginator）
-->

```js

```
  
#### 复现步骤:

1.
2.
